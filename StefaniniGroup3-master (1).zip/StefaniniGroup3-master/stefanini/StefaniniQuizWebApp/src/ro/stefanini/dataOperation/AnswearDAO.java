package ro.stefanini.dataOperation;

import java.util.List;

import ro.stefanini.data.Answear;

public class AnswearDAO {

	public List<Answear> getAnswearsByQuestionId(final Integer questionId) {
		return null;
	}
}
